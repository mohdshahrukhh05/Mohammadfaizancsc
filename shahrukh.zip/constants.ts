// FIX: Add a triple-slash directive to provide TypeScript with Vite's client-side environment variable types.
/// <reference types="vite/client" />

import { BanknotesIcon, CircleStackIcon, DocumentDuplicateIcon, ComputerDesktopIcon, DocumentChartBarIcon, DevicePhoneMobileIcon } from '@heroicons/react/24/outline';
import type { Service, TeamMember } from './types';

export const CONTACT_DETAILS = {
  mobileNumbers: ['8534983041', '9045174146'],
  email: 'faizanjanseva@gmail.com',
  address: 'Kohinoor Road, Noor Nagar, Gali No 26, Moradabad, Uttar Pradesh, India',
  mapCoordinates: { lng: 78.7567, lat: 28.8418 }, // Approx. coordinates for Noor Nagar, Moradabad
};

export const SOCIAL_ACCOUNTS = {
  instagram: 'https://www.instagram.com/faizancsc',
  whatsapp: 'https://wa.me/918534983041', // Using one primary number
};

export const SERVICES: Service[] = [
  {
    name: 'State Bank of India Services',
    description: 'Comprehensive banking services including deposits, withdrawals, and account management.',
    price: 'Varies',
    icon: BanknotesIcon,
  },
  {
    name: 'AEPS Services',
    description: 'Aadhaar Enabled Payment System for easy cash withdrawal, balance inquiry, and mini statements.',
    price: 'Varies',
    icon: DevicePhoneMobileIcon,
  },
  {
    name: 'e-District Certificates',
    description: 'Application for Domicile, Caste, and Income certificates.',
    price: '₹100 per certificate',
    icon: DocumentChartBarIcon,
  },
  {
    name: 'Photocopy & Lamination',
    description: 'High-quality document copying and lamination services.',
    price: 'From ₹1',
    icon: DocumentDuplicateIcon,
  },
  {
    name: 'Bank Account Opening',
    description: 'Hassle-free opening of new bank accounts with our assistance.',
    price: 'Free of Cost',
    icon: CircleStackIcon,
  },
  {
    name: 'General CSC Services',
    description: 'Access to a wide array of government and private services through the CSC portal.',
    price: 'Varies',
    icon: ComputerDesktopIcon,
  },
];

export const TEAM_MEMBERS: TeamMember[] = [
  { name: 'Mohammad Faizan', role: 'Owner', imageUrl: 'https://picsum.photos/seed/faizan/400/400' },
  { name: 'Mohammad Shahrukh', role: 'Manager', imageUrl: 'https://picsum.photos/seed/shahrukh/400/400' },
  { name: 'Mohammad Sadiq', role: 'Staff', imageUrl: 'https://picsum.photos/seed/sadiq/400/400' },
  { name: 'Mohammad Altaf Azam Khan', role: 'Staff', imageUrl: 'https://picsum.photos/seed/altaf/400/400' },
];

// NOTE FOR DEVELOPER:
// The Gemini API key and MapTiler key are accessed via environment variables.
// You must create a .env file in the root of your project and add the following lines:
// API_KEY=AIzaSy... (Your Gemini API Key)
// VITE_MAPTILER_KEY=Biow... (Your MapTiler API Key)
// The `VITE_` prefix is important for Vite projects to expose the variable to the frontend.
// This application code assumes these are set.
export const MAPTILER_API_KEY = import.meta.env.VITE_MAPTILER_KEY || 'BiowIbnYQSapXeBxzL7t';