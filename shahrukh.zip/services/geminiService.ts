
import { GoogleGenAI, Modality } from "@google/genai";

// IMPORTANT: Do NOT hardcode the API key. It should be in an environment variable.
// The user has provided a key, but for security, we must use process.env.
// This code assumes `process.env.API_KEY` is set in the execution environment.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real app, you might show a user-friendly error message.
  console.error("API_KEY environment variable not set.");
}
const ai = new GoogleGenAI({ apiKey: API_KEY! });

const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

export const enhanceImage = async (imageFile: File, prompt: string): Promise<string> => {
  try {
    const imagePart = await fileToGenerativePart(imageFile);
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          imagePart,
          { text: prompt },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image data found in response.");

  } catch (error) {
    console.error("Error enhancing image:", error);
    throw new Error("Failed to enhance the image. Please try again.");
  }
};


export const generateImage = async (prompt: string): Promise<string> => {
  try {
     const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/png',
          aspectRatio: '1:1',
        },
    });

    if (response.generatedImages && response.generatedImages.length > 0) {
        const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
        return `data:image/png;base64,${base64ImageBytes}`;
    }
    throw new Error("No images were generated.");
  } catch (error) {
    console.error("Error generating image:", error);
    throw new Error("Failed to generate the image. Please try again.");
  }
};
