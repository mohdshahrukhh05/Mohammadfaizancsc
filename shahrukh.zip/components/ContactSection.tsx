
import React, { useRef, useEffect } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { CONTACT_DETAILS, SOCIAL_ACCOUNTS, MAPTILER_API_KEY } from '../constants';
import { PhoneIcon, EnvelopeIcon, MapPinIcon } from '@heroicons/react/24/solid';

const ContactSection: React.FC = () => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<maplibregl.Map | null>(null);

  useEffect(() => {
    if (map.current || !mapContainer.current) return;

    const { lng, lat } = CONTACT_DETAILS.mapCoordinates;

    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: `https://api.maptiler.com/maps/streets/style.json?key=${MAPTILER_API_KEY}`,
      center: [lng, lat],
      zoom: 14,
    });

    map.current.addControl(new maplibregl.NavigationControl({}), 'top-right');

    new maplibregl.Marker({ color: "#FF0000" })
      .setLngLat([lng, lat])
      .setPopup(new maplibregl.Popup().setText("Mohammad Faizan Jan Seva Kendra"))
      .addTo(map.current);
      
    return () => {
        map.current?.remove();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800">Get In Touch</h2>
          <p className="text-gray-600 mt-2">We are here to help you.</p>
          <div className="mt-4 w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-1/2 bg-white p-8 rounded-lg shadow-lg">
            <h3 className="text-2xl font-bold mb-6">Contact Details</h3>
            <div className="space-y-4">
              <div className="flex items-start">
                <MapPinIcon className="h-6 w-6 text-blue-600 mt-1 mr-4 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold">Address</h4>
                  <p className="text-gray-600">{CONTACT_DETAILS.address}</p>
                </div>
              </div>
              <div className="flex items-start">
                <PhoneIcon className="h-6 w-6 text-blue-600 mt-1 mr-4 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold">Phone</h4>
                  {CONTACT_DETAILS.mobileNumbers.map(num => (
                     <a key={num} href={`tel:${num}`} className="text-gray-600 block hover:text-blue-600">{num}</a>
                  ))}
                </div>
              </div>
              <div className="flex items-start">
                <EnvelopeIcon className="h-6 w-6 text-blue-600 mt-1 mr-4 flex-shrink-0" />
                <div>
                    <h4 className="font-semibold">Email</h4>
                    <a href={`mailto:${CONTACT_DETAILS.email}`} className="text-gray-600 hover:text-blue-600">{CONTACT_DETAILS.email}</a>
                </div>
              </div>
            </div>
            <div className="mt-8 pt-6 border-t">
                <h4 className="font-semibold mb-2">Follow Us</h4>
                <div className="flex space-x-4">
                    <a href={SOCIAL_ACCOUNTS.instagram} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-pink-500">
                        <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.024.06 1.378.06 3.808s-.012 2.784-.06 3.808c-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.024.048-1.378.06-3.808.06s-2.784-.012-3.808-.06c-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.048-1.024-.06-1.378-.06-3.808s.012-2.784.06-3.808c.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 016.343 2.525c.636-.247 1.363-.416 2.427-.465C9.793 2.013 10.147 2 12.315 2zm0 1.62c-2.403 0-2.73.01-3.682.055-1.12.05-1.622.22-1.954.363-.52.23-.902.51-1.29.9-.387.388-.67.77-.9 1.29-.145.332-.298.834-.363 1.954C2.01 9.27 2 9.6 2 12.007s.01 2.73.055 3.682c.05 1.12.22 1.622.363 1.954.23.52.51.902.9 1.29.388.387.77.67 1.29.9.332.145.834.298 1.954.363 1.095.053 1.43.058 3.8.058s2.705-.005 3.8-.058c1.12-.05 1.622-.22 1.954-.363.52-.23.902-.51 1.29-.9.387-.388.67-.77.9-1.29.145-.332.298-.834-.363-1.954.053-1.095.058-1.43.058-3.8s-.005-2.705-.058-3.8c-.05-1.12-.22-1.622-.363-1.954-.23-.52-.51-.902-.9-1.29-.388-.387-.77-.67-1.29-.9-.332-.145-.834-.298-1.954-.363C15.045 3.63 14.715 3.62 12.315 3.62zM12 7.182c-2.653 0-4.818 2.165-4.818 4.818s2.165 4.818 4.818 4.818 4.818-2.165 4.818-4.818-2.165-4.818-4.818-4.818zm0 7.993c-1.753 0-3.175-1.422-3.175-3.175s1.422-3.175 3.175-3.175 3.175 1.422 3.175 3.175-1.422 3.175-3.175 3.175zm5.16-8.12a1.18 1.18 0 11-2.36 0 1.18 1.18 0 012.36 0z" clipRule="evenodd" /></svg>
                    </a>
                    <a href={SOCIAL_ACCOUNTS.whatsapp} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-green-500">
                        <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.38 1.25 4.85L2 22l5.29-1.38c1.4.74 2.97 1.18 4.62 1.18h.01c5.46 0 9.91-4.45 9.91-9.91s-4.45-9.91-9.92-9.91zM17.48 15.58c-.28-.14-1.64-.81-1.9- .91s-.44-.14-.63.14-.71.91-.88 1.1-.33.21-.61.07s-1.22-.45-2.32-1.43c-.86-.76-1.44-1.71-1.61-2-.17-.28-.01-.44.12-.58.12-.12.28-.33.41-.49.1-.13.17-.21.28-.35.1-.14.07-.28-.01-.42s-.63-1.51-.86-2.07c-.23-.55-.47-.48-.63-.48s-.33-.01-.48-.01c-.16 0-.42.07-.63.35-.22.28-.86 1.05-.86 2.55s.88 2.96 1 3.17c.12.21 1.74 2.65 4.21 3.73.59.26 1.05.41 1.41.53.6.19 1.13.16 1.56.1.48-.07 1.64-.67 1.87-1.32.23-.65.23-1.21.16-1.32c-.07-.11-.26-.18-.54-.32z" /></svg>
                    </a>
                </div>
            </div>
          </div>
          <div className="lg:w-1/2 h-96 lg:h-auto rounded-lg shadow-lg overflow-hidden">
             <div ref={mapContainer} className="w-full h-full" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
