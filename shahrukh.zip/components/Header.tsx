
import React from 'react';
import type { View } from '../types';
import { View as ViewEnum } from '../types';

interface HeaderProps {
  currentView: View;
  setView: (view: View) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, setView }) => {
  const navItems = [ViewEnum.Home, ViewEnum.RequestService, ViewEnum.CheckStatus, ViewEnum.AiTools];

  return (
    <header className="bg-white/80 backdrop-blur-md shadow-md sticky top-0 z-50">
      <nav className="container mx-auto px-6 py-3 flex justify-between items-center">
        <div className="text-2xl font-bold text-blue-600 cursor-pointer" onClick={() => setView(ViewEnum.Home)}>
          M.F. Jan Seva Kendra
        </div>
        <div className="hidden md:flex items-center space-x-2">
          {navItems.map((item) => (
            <button
              key={item}
              onClick={() => setView(item)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-300 ${
                currentView === item
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-600 hover:bg-blue-100 hover:text-blue-700'
              }`}
            >
              {item}
            </button>
          ))}
        </div>
        <div className="md:hidden">
          {/* Mobile menu button can be added here */}
        </div>
      </nav>
    </header>
  );
};

export default Header;
