
import React from 'react';
import type { TeamMember } from '../types';

interface TeamMemberCardProps {
  member: TeamMember;
}

const TeamMemberCard: React.FC<TeamMemberCardProps> = ({ member }) => {
  return (
    <div className="text-center">
      <img
        src={member.imageUrl}
        alt={member.name}
        className="w-40 h-40 mx-auto rounded-full shadow-lg object-cover"
      />
      <h3 className="mt-4 text-xl font-bold text-gray-800">{member.name}</h3>
      <p className="text-blue-600 font-medium">{member.role}</p>
    </div>
  );
};

export default TeamMemberCard;
