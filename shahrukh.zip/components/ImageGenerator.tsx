
import React, { useState } from 'react';
import { generateImage } from '../services/geminiService';
import { SparklesIcon, PhotoIcon } from '@heroicons/react/24/outline';

const ImageGenerator: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async () => {
    if (!prompt) {
      setError("Please enter a prompt to generate an image.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setResult(null);
    try {
      const generatedImageUrl = await generateImage(prompt);
      setResult(generatedImageUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-gray-50 p-8 rounded-lg shadow-lg">
      <h3 className="text-2xl font-bold text-center mb-1">AI Image Generator</h3>
      <p className="text-gray-600 text-center mb-6">Describe the image you want to create, and let AI bring it to life.</p>
      
      <div className="space-y-6">
        <div>
          <label htmlFor="gen-prompt" className="block text-sm font-medium text-gray-700 mb-2">Enter your prompt</label>
          <textarea
            id="gen-prompt"
            rows={3}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            placeholder="e.g., A photorealistic image of an astronaut riding a horse on Mars"
          />
        </div>
        
        <div>
          <button
            onClick={handleSubmit}
            disabled={!prompt || isLoading}
            className="w-full flex items-center justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Generating...
              </>
            ) : (
                <>
                <SparklesIcon className="h-5 w-5 mr-2" />
                Generate Image
                </>
            )}
          </button>
        </div>
        
        {error && <p className="text-red-500 text-center">{error}</p>}
        
        <div className="mt-8">
            {result ? (
                <div className="text-center">
                    <h4 className="font-semibold mb-2">Generated Image</h4>
                    <img src={result} alt="Generated result" className="rounded-lg shadow-md w-full object-contain mx-auto" />
                </div>
            ) : (
                <div className="text-center text-gray-400 border-2 border-dashed border-gray-300 rounded-lg p-12">
                   <PhotoIcon className="mx-auto h-12 w-12" />
                   <p className="mt-2 text-sm">Your generated image will appear here.</p>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default ImageGenerator;
