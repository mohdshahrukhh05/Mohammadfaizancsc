import React, { useState, useEffect } from 'react';
import { enhanceImage } from '../services/geminiService';
import { PhotoIcon, SparklesIcon } from '@heroicons/react/24/outline';

const ImageEnhancer: React.FC = () => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // FIX: Add useEffect to revoke the object URL to prevent memory leaks.
  useEffect(() => {
    // When the component unmounts, or before the preview URL changes,
    // revoke the old object URL to free up memory.
    return () => {
      if (preview) {
        URL.revokeObjectURL(preview);
      }
    };
  }, [preview]);
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageFile(file);
      setPreview(URL.createObjectURL(file));
      setResult(null);
      setError(null);
    }
  };
  
  const handleSubmit = async () => {
    if (!imageFile || !prompt) {
      setError("Please upload an image and provide an editing instruction.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setResult(null);
    try {
      const enhancedImageUrl = await enhanceImage(imageFile, prompt);
      setResult(enhancedImageUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-gray-50 p-8 rounded-lg shadow-lg">
      <h3 className="text-2xl font-bold text-center mb-1">AI Image Editor</h3>
      <p className="text-gray-600 text-center mb-6">Upload an image and tell our AI how to edit it.</p>
      
      <div className="space-y-6">
        <div>
          <label htmlFor="image-upload" className="block text-sm font-medium text-gray-700 mb-2">1. Upload Image</label>
          <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
            <div className="space-y-1 text-center">
              <PhotoIcon className="mx-auto h-12 w-12 text-gray-400" />
              <div className="flex text-sm text-gray-600">
                <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                  <span>Upload a file</span>
                  <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleFileChange} accept="image/*" />
                </label>
                <p className="pl-1">or drag and drop</p>
              </div>
              <p className="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
            </div>
          </div>
        </div>
        
        {preview && (
          <div>
            <label htmlFor="prompt" className="block text-sm font-medium text-gray-700 mb-2">2. Describe Your Edit</label>
            <input
              type="text"
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., Add a retro filter, remove the person in background"
            />
          </div>
        )}
        
        <div>
          <button
            onClick={handleSubmit}
            disabled={!imageFile || !prompt || isLoading}
            className="w-full flex items-center justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Enhancing...
              </>
            ) : (
                <>
                <SparklesIcon className="h-5 w-5 mr-2" />
                Enhance Image
                </>
            )}
          </button>
        </div>
        
        {error && <p className="text-red-500 text-center">{error}</p>}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
            {preview && (
                <div className="text-center">
                    <h4 className="font-semibold mb-2">Original</h4>
                    <img src={preview} alt="Original preview" className="rounded-lg shadow-md w-full object-contain" />
                </div>
            )}
            {result && (
                <div className="text-center">
                    <h4 className="font-semibold mb-2">Edited</h4>
                    <img src={result} alt="Enhanced result" className="rounded-lg shadow-md w-full object-contain" />
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default ImageEnhancer;