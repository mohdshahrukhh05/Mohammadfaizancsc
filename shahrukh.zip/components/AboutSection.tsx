
import React from 'react';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800">About Us</h2>
            <p className="text-gray-600 mt-2">Your Partner in Digital Services</p>
            <div className="mt-4 w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/2">
            <img src="https://picsum.photos/seed/office/800/600" alt="Jan Seva Kendra Office" className="rounded-lg shadow-2xl" />
          </div>
          <div className="md:w-1/2 text-lg">
            <p className="text-gray-700 mb-4">
              Welcome to Mohammad Faizan Jan Seva Kendra, your local Common Service Center (CSC). We are dedicated to bringing a wide range of government and non-government services to your doorstep, making your life simpler and more convenient.
            </p>
            <p className="text-gray-700 mb-4">
              Our mission is to bridge the digital divide by providing seamless access to essential services. Whether you need assistance with banking, official documents, or other digital facilities, our expert team is here to guide you through every step with professionalism and care.
            </p>
            <p className="text-gray-700">
              We pride ourselves on our commitment to customer satisfaction and strive to deliver every service with accuracy and speed.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
