
import React from 'react';
import type { Service } from '../types';

interface ServiceCardProps {
  service: Service;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service }) => {
  const Icon = service.icon;
  return (
    <div className="bg-white p-6 rounded-lg shadow-lg hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 flex flex-col">
      <div className="flex-shrink-0">
        <div className="bg-blue-100 text-blue-600 rounded-full p-4 w-16 h-16 flex items-center justify-center mb-4">
          <Icon className="w-8 h-8" />
        </div>
        <h3 className="text-xl font-bold text-gray-800 mb-2">{service.name}</h3>
        <p className="text-gray-600 mb-4 flex-grow">{service.description}</p>
      </div>
      <div className="mt-auto pt-4 border-t border-gray-100">
        <span className="text-lg font-semibold text-blue-600">{service.price}</span>
      </div>
    </div>
  );
};

export default ServiceCard;
