
import React, { useState } from 'react';
import { SERVICES, CONTACT_DETAILS } from '../constants';
import type { ServiceRequest, View } from '../types';
import { View as ViewEnum } from '../types';
import Modal from './Modal';

interface ServiceRequestFormProps {
  addServiceRequest: (request: ServiceRequest) => void;
  setView: (view: View) => void;
}

const ServiceRequestForm: React.FC<ServiceRequestFormProps> = ({ addServiceRequest, setView }) => {
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [service, setService] = useState(SERVICES[0]?.name || '');
  const [error, setError] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [submittedRequest, setSubmittedRequest] = useState<ServiceRequest | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !contact.trim() || !service) {
      setError('All fields are mandatory.');
      return;
    }
    setError('');

    const newRequest: ServiceRequest = {
      id: `MFJSK-${Date.now()}`,
      name,
      contact,
      service,
      status: 'Pending',
      timestamp: new Date(),
    };

    addServiceRequest(newRequest);
    setSubmittedRequest(newRequest);
    setIsModalOpen(true);

    // Reset form
    setName('');
    setContact('');
    setService(SERVICES[0]?.name || '');
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSubmittedRequest(null);
    setView(ViewEnum.CheckStatus);
  };

  return (
    <div className="bg-white py-20">
      <div className="container mx-auto px-6 max-w-3xl">
        <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800">Request a Service</h2>
            <p className="text-gray-600 mt-2">Fill out the form below to begin.</p>
            <div className="mt-4 w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>

        <div className="bg-gray-50 p-8 rounded-lg shadow-lg">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name</label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>

            <div>
              <label htmlFor="contact" className="block text-sm font-medium text-gray-700">Contact Number or Email</label>
              <input
                type="text"
                id="contact"
                value={contact}
                onChange={(e) => setContact(e.target.value)}
                className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                required
              />
            </div>
            
            <div>
              <label htmlFor="service" className="block text-sm font-medium text-gray-700">Select Service</label>
              <select
                id="service"
                value={service}
                onChange={(e) => setService(e.target.value)}
                className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              >
                {SERVICES.map((s) => (
                  <option key={s.name} value={s.name}>{s.name}</option>
                ))}
              </select>
            </div>

            {error && <p className="text-red-500 text-sm">{error}</p>}

            <div>
              <button
                type="submit"
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Submit Request
              </button>
            </div>
          </form>
        </div>

        <Modal isOpen={isModalOpen} onClose={closeModal} title="Request Submitted!">
          <div className="text-center">
            <p className="text-lg font-semibold text-green-600">Thank You!</p>
            <p className="text-gray-700 mt-2">Your request has been received. Your Request ID is:</p>
            <p className="text-xl font-bold text-blue-600 bg-blue-50 p-2 rounded my-4 select-all">{submittedRequest?.id}</p>
            <p className="text-gray-600 text-sm">Please save this ID to track your status. For faster processing, please contact us at <span className="font-semibold">{CONTACT_DETAILS.mobileNumbers[0]}</span>.</p>
            <button onClick={closeModal} className="mt-6 bg-blue-600 text-white font-bold py-2 px-6 rounded-md hover:bg-blue-700 transition duration-300">
                Check Status Now
            </button>
          </div>
        </Modal>
      </div>
    </div>
  );
};

export default ServiceRequestForm;
