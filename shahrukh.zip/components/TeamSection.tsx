
import React from 'react';
import { TEAM_MEMBERS } from '../constants';
import TeamMemberCard from './TeamMemberCard';

const TeamSection: React.FC = () => {
  return (
    <section id="team" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800">Meet Our Team</h2>
          <p className="text-gray-600 mt-2">The dedicated professionals behind our success.</p>
          <div className="mt-4 w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {TEAM_MEMBERS.map((member) => (
            <TeamMemberCard key={member.name} member={member} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default TeamSection;
