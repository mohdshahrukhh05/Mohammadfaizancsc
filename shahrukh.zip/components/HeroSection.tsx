
import React from 'react';
import type { View } from '../types';
import { View as ViewEnum } from '../types';

interface HeroSectionProps {
  setView: (view: View) => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({ setView }) => {
  return (
    <section className="bg-blue-600 text-white">
      <div className="container mx-auto px-6 py-24 text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-4">
          Mohammad Faizan Jan Seva Kendra
        </h1>
        <p className="text-lg md:text-xl text-blue-200 mb-8 max-w-3xl mx-auto">
          Your trusted one-stop solution for all government, banking, and digital services. Fast, reliable, and efficient.
        </p>
        <div className="space-x-4">
          <button
            onClick={() => setView(ViewEnum.RequestService)}
            className="bg-white text-blue-600 font-bold py-3 px-8 rounded-full hover:bg-blue-100 transition duration-300 transform hover:scale-105"
          >
            Request a Service
          </button>
          <button
            onClick={() => {
                const servicesSection = document.getElementById('services');
                if(servicesSection) servicesSection.scrollIntoView({ behavior: 'smooth' });
            }}
            className="bg-transparent border-2 border-white text-white font-bold py-3 px-8 rounded-full hover:bg-white hover:text-blue-600 transition duration-300"
          >
            Explore Services
          </button>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
