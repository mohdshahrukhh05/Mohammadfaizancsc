
import React, { useState } from 'react';
import type { ServiceRequest } from '../types';
import Modal from './Modal';

interface StatusCheckProps {
  serviceRequests: ServiceRequest[];
}

const StatusCheck: React.FC<StatusCheckProps> = ({ serviceRequests }) => {
  const [requestId, setRequestId] = useState('');
  const [foundRequest, setFoundRequest] = useState<ServiceRequest | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleCheckStatus = (e: React.FormEvent) => {
    e.preventDefault();
    const request = serviceRequests.find(r => r.id.toLowerCase() === requestId.trim().toLowerCase());
    if (request) {
      setFoundRequest(request);
      setNotFound(false);
    } else {
      setFoundRequest(null);
      setNotFound(true);
    }
    setIsModalOpen(true);
  };
  
  const getStatusColor = (status: ServiceRequest['status']) => {
    switch (status) {
        case 'Pending': return 'text-yellow-600 bg-yellow-100';
        case 'In Progress': return 'text-blue-600 bg-blue-100';
        case 'Completed': return 'text-green-600 bg-green-100';
        case 'Rejected': return 'text-red-600 bg-red-100';
        default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="bg-white py-20">
      <div className="container mx-auto px-6 max-w-2xl">
        <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800">Check Request Status</h2>
            <p className="text-gray-600 mt-2">Enter your Request ID to see the current status.</p>
            <div className="mt-4 w-24 h-1 bg-blue-600 mx-auto"></div>
        </div>

        <div className="bg-gray-50 p-8 rounded-lg shadow-lg">
          <form onSubmit={handleCheckStatus} className="flex flex-col sm:flex-row gap-4">
            <input
              type="text"
              value={requestId}
              onChange={(e) => setRequestId(e.target.value)}
              placeholder="Enter your Request ID (e.g., MFJSK-123...)"
              className="flex-grow w-full px-4 py-3 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              required
            />
            <button
              type="submit"
              className="sm:w-auto w-full flex justify-center py-3 px-6 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Check Status
            </button>
          </form>
        </div>
        
        <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Request Status">
           {foundRequest && (
             <div className="space-y-3">
               <p><strong>Request ID:</strong> {foundRequest.id}</p>
               <p><strong>Service:</strong> {foundRequest.service}</p>
               <p><strong>Name:</strong> {foundRequest.name}</p>
               <p><strong>Submitted:</strong> {foundRequest.timestamp.toLocaleString()}</p>
               <p className="flex items-center gap-2"><strong>Status:</strong> <span className={`px-3 py-1 text-sm font-semibold rounded-full ${getStatusColor(foundRequest.status)}`}>{foundRequest.status}</span></p>
               <p className="text-sm text-gray-500 pt-4">If you have any questions, please contact us.</p>
             </div>
           )}
           {notFound && (
             <div className="text-center">
               <p className="text-red-500 font-semibold">Request ID not found.</p>
               <p className="text-gray-600 mt-2">Please check the ID and try again.</p>
             </div>
           )}
        </Modal>
      </div>
    </div>
  );
};

export default StatusCheck;
