
import React from 'react';
import { CONTACT_DETAILS } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto px-6 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-left">
          <div className="mb-4 md:mb-0">
            <h3 className="text-xl font-bold">Mohammad Faizan Jan Seva Kendra</h3>
            <p className="text-gray-400">{CONTACT_DETAILS.address}</p>
          </div>
          <div className="text-gray-400">
            <p>&copy; {new Date().getFullYear()} Mohammad Faizan Jan Seva Kendra. All Rights Reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
