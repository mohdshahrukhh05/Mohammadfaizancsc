
import React, { useState } from 'react';
import ImageEnhancer from './ImageEnhancer';
import ImageGenerator from './ImageGenerator';

type AiTool = 'enhancer' | 'generator';

const AiToolsSection: React.FC = () => {
    const [activeTool, setActiveTool] = useState<AiTool>('enhancer');

    return (
        <div className="bg-white py-20">
            <div className="container mx-auto px-6">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-gray-800">AI-Powered Tools</h2>
                    <p className="text-gray-600 mt-2">Experience the future with our Gemini-powered features.</p>
                    <div className="mt-4 w-24 h-1 bg-blue-600 mx-auto"></div>
                </div>

                <div className="flex justify-center mb-8 border-b">
                    <button
                        onClick={() => setActiveTool('enhancer')}
                        className={`px-6 py-3 font-medium text-lg transition-colors duration-200 ${activeTool === 'enhancer' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
                    >
                        Image Editor
                    </button>
                    <button
                        onClick={() => setActiveTool('generator')}
                        className={`px-6 py-3 font-medium text-lg transition-colors duration-200 ${activeTool === 'generator' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500'}`}
                    >
                        Image Generator
                    </button>
                </div>

                <div className="max-w-4xl mx-auto">
                    {activeTool === 'enhancer' && <ImageEnhancer />}
                    {activeTool === 'generator' && <ImageGenerator />}
                </div>
            </div>
        </div>
    );
};

export default AiToolsSection;
