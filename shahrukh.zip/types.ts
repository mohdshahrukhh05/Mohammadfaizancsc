
export enum View {
  Home = 'Home',
  RequestService = 'Request Service',
  CheckStatus = 'Check Status',
  AiTools = 'AI Tools',
}

export interface Service {
  name: string;
  description: string;
  price: string;
  icon: React.ComponentType<{ className?: string }>;
}

export interface TeamMember {
  name: string;
  role: string;
  imageUrl: string;
}

export interface ServiceRequest {
  id: string;
  name: string;
  contact: string;
  service: string;
  status: 'Pending' | 'In Progress' | 'Completed' | 'Rejected';
  timestamp: Date;
}
