
import React, { useState } from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import ServicesSection from './components/ServicesSection';
import TeamSection from './components/TeamSection';
import ContactSection from './components/ContactSection';
import ServiceRequestForm from './components/ServiceRequestForm';
import StatusCheck from './components/StatusCheck';
import AiToolsSection from './components/AiToolsSection';
import Footer from './components/Footer';
import type { ServiceRequest } from './types';
import { View } from './types';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.Home);
  const [serviceRequests, setServiceRequests] = useState<ServiceRequest[]>([]);

  const addServiceRequest = (request: ServiceRequest) => {
    setServiceRequests(prevRequests => [...prevRequests, request]);
  };

  const renderView = () => {
    switch (currentView) {
      case View.RequestService:
        return <ServiceRequestForm addServiceRequest={addServiceRequest} setView={setCurrentView} />;
      case View.CheckStatus:
        return <StatusCheck serviceRequests={serviceRequests} />;
      case View.AiTools:
        return <AiToolsSection />;
      case View.Home:
      default:
        return (
          <>
            <HeroSection setView={setCurrentView} />
            <AboutSection />
            <ServicesSection />
            <TeamSection />
            <ContactSection />
          </>
        );
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen text-gray-800 font-sans">
      <Header currentView={currentView} setView={setCurrentView} />
      <main>
        {renderView()}
      </main>
      <Footer />
    </div>
  );
};

export default App;
